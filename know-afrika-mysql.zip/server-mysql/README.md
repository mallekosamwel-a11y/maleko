# Know Afrika — Node/Express server (MySQL version)

This one server does two jobs: it's your API (packages, magazines,
site settings) and it serves the website itself (everything in
`/public`). One thing to run, one thing to host.

Unlike the SQLite version, this one needs a **separate MySQL
database** to connect to — it's no longer a single file that lives
inside this project.

## Option A — MySQL on your own computer (for testing)

1. Install MySQL: https://dev.mysql.com/downloads/installer/ (Windows) or via Homebrew (`brew install mysql`) on Mac
2. Start it, and note the root password you set during install
3. Create a database:
   ```
   mysql -u root -p -e "CREATE DATABASE know_afrika;"
   ```
4. In `.env` (copy `.env.example` and rename it), set:
   ```
   DB_HOST=127.0.0.1
   DB_USER=root
   DB_PASSWORD=your-mysql-root-password
   DB_NAME=know_afrika
   ```

## Option B — A hosted MySQL database (needed once you go live)

Render doesn't offer managed MySQL directly, so you'll need a
separate provider. Reasonable options with usable free tiers:

- **PlanetScale** (https://planetscale.com) — generous free tier, easiest signup
- **Railway** (https://railway.app) — has a MySQL template you can add alongside your web service
- **Aiven** — also has a free MySQL tier

Whichever you pick, they'll give you five values — host, port, user,
password, database name — copy them directly into `.env` (locally)
or into your host's Environment Variables screen (once deployed).

## Running it locally

```
npm install
```
Downloads the handful of packages this depends on (Express, mysql2,
etc). Only needed once. Unlike the old SQLite version, nothing here
needs to compile native code, so this step should be simpler/faster.

```
node create-admin.js youremail@example.com yourpassword
```
Creates your login for `admin.html`. The very first time you run
this (or `npm start`), the server also automatically creates all the
necessary tables and fills them with sample content — you don't need
to run any SQL by hand.

```
npm start
```
Starts the server. You should see:
`Know Afrika server running at http://localhost:3000`

If you see a database connection error instead, double check the
five `DB_...` values in `.env` match your MySQL setup exactly.

Open `http://localhost:3000` for the site, add `/admin.html` for the
admin panel. Stop the server anytime with Ctrl+C.

## Photos

Same as before — every photo field in `admin.html` has an upload
button. Pick a photo from your computer, it uploads to
`public/uploads/` and fills in the field automatically.

## Putting it online (hosting)

Same as the SQLite version: needs a host that keeps a Node server
running continuously (Render or Railway both work). The database
itself now lives somewhere separate (see Option B above) rather than
needing its own persistent disk — that's actually one less thing to
configure on your hosting provider compared to before.

**Still needs persistent storage for `public/uploads/`** though —
uploaded photos are still local files on whichever server runs this
code, so that part of the earlier advice still applies.

## Security note

Same protections as before — hashed passwords, safe parameterized
queries (this file never builds SQL by joining text together, which
is what keeps it safe from SQL injection), rate-limited login,
protective headers, and an auto-generated `JWT_SECRET`. Nothing
about switching to MySQL changes any of that.
