// ===================================================================
// Know Afrika — routes/upload.js
// POST /api/upload — admin only. Accepts one image file, saves it
// into public/uploads/, and returns the URL to use as a package or
// magazine's image. This is what makes photos admin-updatable
// without anyone touching code or hunting for image URLs elsewhere.
// ===================================================================

const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const express = require("express");
const multer = require("multer");
const { requireAuth } = require("../middleware/auth");

const UPLOADS_DIR = path.join(__dirname, "..", "public", "uploads");
fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const ALLOWED_TYPES = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "image/gif": ".gif"
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const ext = ALLOWED_TYPES[file.mimetype] || path.extname(file.originalname) || "";
    const name = Date.now() + "-" + crypto.randomBytes(6).toString("hex") + ext;
    cb(null, name);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 8 * 1024 * 1024 }, // 8MB per photo
  fileFilter: (req, file, cb) => {
    if (ALLOWED_TYPES[file.mimetype]) cb(null, true);
    else cb(new Error("Only JPG, PNG, WEBP, or GIF images are allowed."));
  }
});

const router = express.Router();

router.post("/", requireAuth, (req, res) => {
  upload.single("image")(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: "No image was uploaded." });
    res.json({ url: "/uploads/" + req.file.filename });
  });
});

module.exports = router;
