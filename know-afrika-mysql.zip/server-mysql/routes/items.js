// ===================================================================
// Know Afrika — routes/items.js
// Creates the GET/PUT/DELETE routes for a collection (packages or
// magazines). Both collections have the same shape of operations,
// so this one factory function serves both instead of duplicating
// four routes twice.
//
//   GET    /api/<collection>       -> list everything (public)
//   GET    /api/<collection>/:id   -> one item (public)
//   PUT    /api/<collection>/:id   -> create or update (admin only)
//   DELETE /api/<collection>/:id   -> remove (admin only)
//
// Every handler below is async and wrapped in try/catch, since MySQL
// queries are asynchronous and can genuinely fail (connection drop,
// bad query) in ways a local SQLite file rarely did.
// ===================================================================

const express = require("express");
const db = require("../db");
const { requireAuth } = require("../middleware/auth");

function createItemsRouter(kind) {
  const router = express.Router();
  const getAll = kind === "packages" ? db.getPackages : db.getMagazines;
  const getOne = kind === "packages" ? db.getPackage : db.getMagazine;
  const saveOne = kind === "packages" ? db.savePackage : db.saveMagazine;
  const deleteOne = kind === "packages" ? db.deletePackage : db.deleteMagazine;

  router.get("/", async (req, res) => {
    try {
      res.json(await getAll());
    } catch (err) {
      res.status(500).json({ error: "Could not load data: " + err.message });
    }
  });

  router.get("/:id", async (req, res) => {
    try {
      const item = await getOne(req.params.id);
      if (!item) return res.status(404).json({ error: "Not found." });
      res.json(item);
    } catch (err) {
      res.status(500).json({ error: "Could not load data: " + err.message });
    }
  });

  router.put("/:id", requireAuth, async (req, res) => {
    try {
      const record = Object.assign({}, req.body, { id: req.params.id });
      res.json(await saveOne(record));
    } catch (err) {
      res.status(500).json({ error: "Could not save: " + err.message });
    }
  });

  router.delete("/:id", requireAuth, async (req, res) => {
    try {
      await deleteOne(req.params.id);
      res.json({ deleted: true });
    } catch (err) {
      res.status(500).json({ error: "Could not delete: " + err.message });
    }
  });

  return router;
}

module.exports = createItemsRouter;
