// ===================================================================
// Know Afrika — routes/settings.js
// GET  /api/settings  -> brand + footer info (public)
// PUT  /api/settings  -> update it (admin only)
// ===================================================================

const express = require("express");
const db = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    res.json(await db.getSettings());
  } catch (err) {
    res.status(500).json({ error: "Could not load settings: " + err.message });
  }
});

router.put("/", requireAuth, async (req, res) => {
  try {
    res.json(await db.saveSettings(req.body));
  } catch (err) {
    res.status(500).json({ error: "Could not save settings: " + err.message });
  }
});

module.exports = router;
