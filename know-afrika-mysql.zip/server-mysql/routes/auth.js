// ===================================================================
// Know Afrika — routes/auth.js
// POST /api/auth/login — checks credentials, returns a login token.
// ===================================================================

const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const rateLimit = require("express-rate-limit");
const db = require("../db");
const { SECRET } = require("../middleware/auth");

const router = express.Router();

// Limits login attempts so a password can't be guessed thousands of
// times in a row. After 5 failed tries from the same visitor within
// 15 minutes, further attempts are blocked for the rest of that window.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many sign-in attempts. Please wait 15 minutes and try again." }
});

router.post("/login", loginLimiter, async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  try {
    const admin = await db.getAdminByEmail(email);
    if (!admin || !bcrypt.compareSync(password, admin.passwordHash)) {
      return res.status(401).json({ error: "Incorrect email or password." });
    }

    const token = jwt.sign({ email: admin.email }, SECRET, { expiresIn: "7d" });
    res.json({ token, email: admin.email });
  } catch (err) {
    res.status(500).json({ error: "Sign-in failed: " + err.message });
  }
});

module.exports = router;
