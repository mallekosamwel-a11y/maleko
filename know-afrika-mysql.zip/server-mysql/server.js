// ===================================================================
// Know Afrika — server.js
// One server serves both the API (/api/...) and the website files
// (everything in /public), so there's only one thing to run and host.
// ===================================================================

require("dotenv").config();
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");

// ------------------------------------------------------------------
// Security fix #1: never launch with the placeholder login secret.
// If JWT_SECRET is missing or still set to the example value, generate
// a real random one now and save it into .env so it stays the same
// across restarts (otherwise everyone would be signed out every time
// the server restarts).
// ------------------------------------------------------------------
function ensureJwtSecret() {
  const placeholder = "change-this-to-a-long-random-string";
  if (process.env.JWT_SECRET && process.env.JWT_SECRET !== placeholder) return;

  const secret = crypto.randomBytes(48).toString("hex");
  process.env.JWT_SECRET = secret;

  const envPath = path.join(__dirname, ".env");
  try {
    let contents = fs.existsSync(envPath) ? fs.readFileSync(envPath, "utf8") : "";
    if (/^JWT_SECRET=.*$/m.test(contents)) {
      contents = contents.replace(/^JWT_SECRET=.*$/m, "JWT_SECRET=" + secret);
    } else {
      contents += (contents && !contents.endsWith("\n") ? "\n" : "") + "JWT_SECRET=" + secret + "\n";
    }
    fs.writeFileSync(envPath, contents);
    console.log("Generated a new JWT_SECRET and saved it to .env");
  } catch (err) {
    console.warn("Could not save the generated JWT_SECRET to .env — it will change every restart until you set one manually:", err.message);
  }
}
ensureJwtSecret();

const authRouter = require("./routes/auth");
const createItemsRouter = require("./routes/items");
const settingsRouter = require("./routes/settings");
const uploadRouter = require("./routes/upload");
const db = require("./db");

const app = express();

// Security fix #4: standard protective HTTP headers.
// contentSecurityPolicy is switched off here because this site loads
// Google Fonts and photos from images.unsplash.com (plus admin-uploaded
// photos served from /uploads) — a default CSP would silently block
// those. Worth tightening to an explicit allow-list once every photo
// is either uploaded through admin.html or on your own domain.
app.use(helmet({ contentSecurityPolicy: false }));

// Security fix #5: don't allow every website on the internet to call
// this API. Since the public site and admin panel are served by this
// same server, they never need CORS at all (same-origin requests
// aren't affected by it). Only enable it if you set ALLOWED_ORIGIN —
// e.g. if you later build a separate app that needs to call this API
// from a different address.
if (process.env.ALLOWED_ORIGIN) {
  app.use(cors({ origin: process.env.ALLOWED_ORIGIN }));
}

app.use(express.json());

app.use("/api/auth", authRouter);
app.use("/api/packages", createItemsRouter("packages"));
app.use("/api/magazines", createItemsRouter("magazines"));
app.use("/api/settings", settingsRouter);
app.use("/api/upload", uploadRouter);

// The website itself (index.html, admin.html, css/, js/) lives in /public
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;

// MySQL needs its tables created and seeded before the server starts
// accepting requests — unlike the old SQLite file, this doesn't
// happen automatically just by requiring db.js.
(async () => {
  try {
    await db.ensureSchema();
    await db.seedIfEmpty();
  } catch (err) {
    console.error("Could not connect to MySQL or set up the database:", err.message);
    console.error("Check DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME in your .env file, and that the MySQL server is reachable.");
    process.exit(1);
  }

  app.listen(PORT, () => {
    console.log("Know Afrika server running at http://localhost:" + PORT);
  });
})();
