CREATE TABLE IF NOT EXISTS packages (
  id VARCHAR(255) PRIMARY KEY,
  title VARCHAR(500) NOT NULL,
  location VARCHAR(500),
  image TEXT,
  featured TINYINT(1) DEFAULT 0,
  date VARCHAR(255),
  duration VARCHAR(255),
  price DECIMAL(10,2),
  currency VARCHAR(10),
  priceUnit VARCHAR(100),
  rating DECIMAL(3,2),
  ratingCount INT,
  summary TEXT,
  body LONGTEXT,
  operator LONGTEXT,
  reviews LONGTEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS magazines (
  id VARCHAR(255) PRIMARY KEY,
  title VARCHAR(500) NOT NULL,
  location VARCHAR(500),
  image TEXT,
  featured TINYINT(1) DEFAULT 0,
  date VARCHAR(255),
  author VARCHAR(255),
  readTime VARCHAR(100),
  rating DECIMAL(3,2),
  ratingCount INT,
  summary TEXT,
  body LONGTEXT,
  operator LONGTEXT,
  reviews LONGTEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS site_config (
  id INT PRIMARY KEY,
  brandName VARCHAR(255),
  tagline VARCHAR(500),
  footerLegalName VARCHAR(255),
  footerEmail VARCHAR(255),
  footerPhone VARCHAR(100),
  footerWhatsapp VARCHAR(100),
  footerAddress VARCHAR(500),
  footerMapsQuery VARCHAR(500),
  footerSocials TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS admins (
  email VARCHAR(255) PRIMARY KEY,
  passwordHash VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
