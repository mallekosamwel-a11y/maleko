// ===================================================================
// Know Afrika — admin.js
// Sign in, then manage settings, packages, and magazines — all
// writes go straight to this server's own API (/api/...).
// ===================================================================

const API = ""; // same origin — server serves both the API and this page
const TOKEN_KEY = "know-afrika-admin-token";

function getToken() { return localStorage.getItem(TOKEN_KEY); }
function setToken(t) { localStorage.setItem(TOKEN_KEY, t); }
function clearToken() { localStorage.removeItem(TOKEN_KEY); }

async function apiGet(path) {
  const res = await fetch(API + path);
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || "Request failed");
  return res.json();
}

async function apiWrite(path, method, body) {
  const res = await fetch(API + path, {
    method,
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + getToken()
    },
    body: body ? JSON.stringify(body) : undefined
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || "Request failed");
  return res.json();
}

async function uploadImage(file) {
  const formData = new FormData();
  formData.append("image", file);
  const res = await fetch("/api/upload", {
    method: "POST",
    headers: { "Authorization": "Bearer " + getToken() },
    body: formData
  });
  const result = await res.json();
  if (!res.ok) throw new Error(result.error || "Upload failed");
  return result.url;
}

// Wires a file input to upload on selection, filling in the given URL
// input and showing progress/errors in the given status element.
function wireImageUpload(fileInput, urlInput, statusEl) {
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files[0];
    if (!file) return;
    statusEl.textContent = "Uploading…";
    statusEl.className = "upload-status";
    try {
      const url = await uploadImage(file);
      urlInput.value = url;
      statusEl.textContent = "Uploaded ✓";
      statusEl.className = "upload-status success";
    } catch (err) {
      statusEl.textContent = "Upload failed: " + err.message;
      statusEl.className = "upload-status error";
    }
  });
}

const SOCIAL_PLATFORMS = ["Instagram", "Facebook", "X", "YouTube", "WhatsApp"];
const ICON_FOR = { Instagram: "instagram", Facebook: "facebook", X: "x", YouTube: "youtube", WhatsApp: "whatsapp" };

const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

function slugify(text) {
  return text.toLowerCase().trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function setStatus(el, message, isError) {
  el.textContent = message;
  el.className = "status " + (isError ? "error" : "success");
}

/* ------------------------- repeatable rows ------------------------- */

function addSocialRow(container, social) {
  const row = document.createElement("div");
  row.className = "row";
  row.innerHTML =
    '<select class="social-platform">' +
      SOCIAL_PLATFORMS.map(p => '<option value="' + p + '">' + p + "</option>").join("") +
    "</select>" +
    '<input type="url" class="social-url" placeholder="https://...">' +
    '<button type="button" class="remove-row">Remove</button>';
  container.appendChild(row);
  if (social) {
    row.querySelector(".social-platform").value = social.name;
    row.querySelector(".social-url").value = social.url;
  }
  row.querySelector(".remove-row").addEventListener("click", () => row.remove());
}

function collectSocials(container) {
  return $$(".row", container).map(row => {
    const name = row.querySelector(".social-platform").value;
    return { name, url: row.querySelector(".social-url").value.trim(), icon: ICON_FOR[name] || "" };
  }).filter(s => s.url);
}

function addBlockRow(container, block) {
  const type = block ? block.type : "text";
  const row = document.createElement("div");
  row.className = "row";
  row.dataset.type = type;
  if (type === "text") {
    row.innerHTML =
      '<textarea class="block-text" placeholder="Paragraph text"></textarea>' +
      '<button type="button" class="remove-row">Remove</button>';
  } else {
    row.innerHTML =
      '<div style="flex:1">' +
        '<input type="url" class="block-image-src" placeholder="Upload a photo below, or paste an image URL"><br><br>' +
        '<input type="file" class="block-image-file" accept="image/jpeg,image/png,image/webp,image/gif"><br>' +
        '<p class="upload-status block-image-status"></p>' +
        '<input type="text" class="block-image-caption" placeholder="Caption (optional)">' +
      "</div>" +
      '<button type="button" class="remove-row">Remove</button>';
  }
  container.appendChild(row);
  if (block) {
    if (type === "text") row.querySelector(".block-text").value = block.content || "";
    else {
      row.querySelector(".block-image-src").value = block.src || "";
      row.querySelector(".block-image-caption").value = block.caption || "";
    }
  }
  row.querySelector(".remove-row").addEventListener("click", () => row.remove());
  if (type === "image") {
    wireImageUpload(
      row.querySelector(".block-image-file"),
      row.querySelector(".block-image-src"),
      row.querySelector(".block-image-status")
    );
  }
}

function collectBlocks(container) {
  return $$(".row", container).map(row => {
    if (row.dataset.type === "text") {
      const content = row.querySelector(".block-text").value.trim();
      return content ? { type: "text", content } : null;
    }
    const src = row.querySelector(".block-image-src").value.trim();
    if (!src) return null;
    return { type: "image", src, caption: row.querySelector(".block-image-caption").value.trim() };
  }).filter(Boolean);
}

/* ------------------------------ auth ------------------------------ */

$("#login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = $("#login-email").value.trim();
  const password = $("#login-password").value;
  $("#login-error").textContent = "";
  try {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const result = await res.json();
    if (!res.ok) throw new Error(result.error || "Sign-in failed");
    setToken(result.token);
    showSignedIn();
  } catch (err) {
    $("#login-error").textContent = "Sign-in failed: " + err.message;
  }
});

$("#signout-btn").addEventListener("click", () => {
  clearToken();
  showSignedOut();
});

function showSignedIn() {
  $("#login-section").hidden = true;
  $("#admin-main").hidden = false;
  $("#signout-btn").hidden = false;
  loadSettings();
  loadList("packages");
  loadList("magazines");
}

function showSignedOut() {
  $("#login-section").hidden = false;
  $("#admin-main").hidden = true;
  $("#signout-btn").hidden = true;
}

// On page load, if we already have a saved token, try going straight in.
// (The token itself gets validated the moment any protected request is made;
// if it's expired, that request will fail and prompt a fresh sign-in.)
if (getToken()) showSignedIn();
else showSignedOut();

/* --------------------------- tab switching --------------------------- */

$$(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    $$(".tab-btn").forEach(b => b.classList.remove("active"));
    $$(".tab-panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    $("#tab-" + btn.dataset.tab).classList.add("active");
  });
});
$(".tab-btn").classList.add("active");
$("#tab-settings").classList.add("active");

/* --------------------------- cover photo uploads --------------------------- */

wireImageUpload($("#package-image-file"), $("#package-image"), $("#package-image-status"));
wireImageUpload($("#magazine-image-file"), $("#magazine-image"), $("#magazine-image-status"));

/* --------------------------- site settings --------------------------- */

async function loadSettings() {
  const c = await apiGet("/api/settings");
  $("#settings-brand-name").value = c.brand?.name || "";
  $("#settings-tagline").value = c.brand?.tagline || "";
  $("#settings-legal-name").value = c.footer?.legalName || "";
  $("#settings-email").value = c.footer?.email || "";
  $("#settings-phone").value = c.footer?.phone || "";
  $("#settings-whatsapp").value = c.footer?.whatsapp || "";
  $("#settings-address").value = c.footer?.address || "";
  $("#settings-maps-query").value = c.footer?.mapsQuery || "";
  $("#settings-socials").innerHTML = "";
  (c.footer?.socials || []).forEach(s => addSocialRow($("#settings-socials"), s));
}

$("#settings-add-social").addEventListener("click", () => addSocialRow($("#settings-socials")));

$("#settings-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const statusEl = $("#settings-status");
  try {
    await apiWrite("/api/settings", "PUT", {
      brand: {
        name: $("#settings-brand-name").value.trim(),
        tagline: $("#settings-tagline").value.trim()
      },
      footer: {
        legalName: $("#settings-legal-name").value.trim(),
        email: $("#settings-email").value.trim(),
        phone: $("#settings-phone").value.trim(),
        whatsapp: $("#settings-whatsapp").value.trim(),
        address: $("#settings-address").value.trim(),
        mapsQuery: $("#settings-maps-query").value.trim(),
        socials: collectSocials($("#settings-socials"))
      }
    });
    setStatus(statusEl, "Saved.", false);
  } catch (err) {
    setStatus(statusEl, "Could not save: " + err.message, true);
  }
});

/* ------------------------ packages / magazines ------------------------ */
// Shared logic parameterised by "kind" so packages and magazines
// (which differ only in a couple of fields) don't need duplicated code.

const KIND_CONFIG = {
  package: {
    collectionName: "packages",
    apiPath: "/api/packages",
    listEl: () => $("#packages-list"),
    formEl: () => $("#package-form"),
    newBtn: () => $("#packages-new-btn"),
    cancelBtn: () => $("#package-cancel-btn"),
    statusEl: () => $("#package-status"),
    headingEl: () => $("#package-form-heading"),
    bodyRowsEl: () => $("#package-body-rows"),
    opSocialsEl: () => $("#package-op-socials"),
    prefix: "package"
  },
  magazine: {
    collectionName: "magazines",
    apiPath: "/api/magazines",
    listEl: () => $("#magazines-list"),
    formEl: () => $("#magazine-form"),
    newBtn: () => $("#magazines-new-btn"),
    cancelBtn: () => $("#magazine-cancel-btn"),
    statusEl: () => $("#magazine-status"),
    headingEl: () => $("#magazine-form-heading"),
    bodyRowsEl: () => $("#magazine-body-rows"),
    opSocialsEl: () => $("#magazine-op-socials"),
    prefix: "magazine"
  }
};

function fieldsFor(kind) {
  const p = KIND_CONFIG[kind].prefix;
  return {
    docId: $("#" + p + "-doc-id"),
    title: $("#" + p + "-title"),
    location: $("#" + p + "-location"),
    image: $("#" + p + "-image"),
    featured: $("#" + p + "-featured"),
    date: $("#" + p + "-date"),
    rating: $("#" + p + "-rating"),
    ratingCount: $("#" + p + "-rating-count"),
    summary: $("#" + p + "-summary"),
    opName: $("#" + p + "-op-name"),
    opAddress: $("#" + p + "-op-address"),
    opLocation: $("#" + p + "-op-location"),
    opEmail: $("#" + p + "-op-email"),
    opPhone: $("#" + p + "-op-phone"),
    // package-only
    duration: kind === "package" ? $("#package-duration") : null,
    price: kind === "package" ? $("#package-price") : null,
    currency: kind === "package" ? $("#package-currency") : null,
    priceUnit: kind === "package" ? $("#package-price-unit") : null,
    // magazine-only
    author: kind === "magazine" ? $("#magazine-author") : null,
    readTime: kind === "magazine" ? $("#magazine-read-time") : null
  };
}

async function loadList(kind) {
  const cfg = KIND_CONFIG[kind];
  const items = await apiGet(cfg.apiPath);
  const listEl = cfg.listEl();
  listEl.innerHTML = "";
  items.forEach(data => {
    const li = document.createElement("li");
    li.innerHTML =
      "<span>" + (data.title || data.id) + "</span>" +
      '<span class="item-actions">' +
        '<button type="button" class="edit-btn">Edit</button>' +
        '<button type="button" class="delete-btn">Delete</button>' +
      "</span>";
    li.querySelector(".edit-btn").addEventListener("click", () => openForm(kind, data.id, data));
    li.querySelector(".delete-btn").addEventListener("click", async () => {
      if (!confirm('Delete "' + (data.title || data.id) + '"? This cannot be undone.')) return;
      await apiWrite(cfg.apiPath + "/" + data.id, "DELETE");
      loadList(kind);
    });
    listEl.appendChild(li);
  });
}

function openForm(kind, docId, data) {
  const cfg = KIND_CONFIG[kind];
  const f = fieldsFor(kind);
  cfg.formEl().hidden = false;
  cfg.headingEl().textContent = docId ? "Edit: " + (data.title || docId) : "New " + kind;

  f.docId.value = docId || "";
  f.title.value = data?.title || "";
  f.location.value = data?.location || "";
  f.image.value = data?.image || "";
  f.featured.checked = !!data?.featured;
  f.date.value = data?.date || "";
  f.rating.value = data?.rating ?? 5;
  f.ratingCount.value = data?.ratingCount ?? 0;
  f.summary.value = data?.summary || "";
  f.opName.value = data?.operator?.name || "";
  f.opAddress.value = data?.operator?.address || "";
  f.opLocation.value = data?.operator?.location || "";
  f.opEmail.value = data?.operator?.email || "";
  f.opPhone.value = data?.operator?.phone || "";

  if (kind === "package") {
    f.duration.value = data?.duration || "";
    f.price.value = data?.price ?? 0;
    f.currency.value = data?.currency || "USD";
    f.priceUnit.value = data?.priceUnit || "per person";
  } else {
    f.author.value = data?.author || "";
    f.readTime.value = data?.readTime || "";
  }

  cfg.bodyRowsEl().innerHTML = "";
  (data?.body || []).forEach(b => addBlockRow(cfg.bodyRowsEl(), b));

  cfg.opSocialsEl().innerHTML = "";
  (data?.operator?.socials || []).forEach(s => addSocialRow(cfg.opSocialsEl(), s));

  cfg.statusEl().textContent = "";
  cfg.formEl().scrollIntoView({ behavior: "smooth" });
}

function closeForm(kind) {
  const cfg = KIND_CONFIG[kind];
  cfg.formEl().reset();
  cfg.formEl().hidden = true;
  cfg.bodyRowsEl().innerHTML = "";
  cfg.opSocialsEl().innerHTML = "";
}

function wireKind(kind) {
  const cfg = KIND_CONFIG[kind];

  cfg.newBtn().addEventListener("click", () => openForm(kind, null, null));
  cfg.cancelBtn().addEventListener("click", () => closeForm(kind));

  $$('[data-add-block]', cfg.formEl()).forEach(btn => {
    btn.addEventListener("click", () => addBlockRow(cfg.bodyRowsEl(), { type: btn.dataset.addBlock }));
  });
  cfg.formEl().querySelector(kind === "package" ? "#package-op-add-social" : "#magazine-op-add-social")
    .addEventListener("click", () => addSocialRow(cfg.opSocialsEl()));

  cfg.formEl().addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = fieldsFor(kind);
    const statusEl = cfg.statusEl();
    const title = f.title.value.trim();
    if (!title) return;

    const docId = f.docId.value || slugify(title);

    const record = {
      title,
      location: f.location.value.trim(),
      image: f.image.value.trim(),
      featured: f.featured.checked,
      date: f.date.value.trim(),
      rating: parseFloat(f.rating.value) || 0,
      ratingCount: parseInt(f.ratingCount.value, 10) || 0,
      summary: f.summary.value.trim(),
      body: collectBlocks(cfg.bodyRowsEl()),
      operator: {
        name: f.opName.value.trim(),
        address: f.opAddress.value.trim(),
        location: f.opLocation.value.trim(),
        email: f.opEmail.value.trim(),
        phone: f.opPhone.value.trim(),
        socials: collectSocials(cfg.opSocialsEl())
      },
      reviews: [] // existing reviews are preserved separately; see note below
    };

    if (kind === "package") {
      record.duration = f.duration.value.trim();
      record.price = parseFloat(f.price.value) || 0;
      record.currency = f.currency.value.trim();
      record.priceUnit = f.priceUnit.value.trim();
    } else {
      record.author = f.author.value.trim();
      record.readTime = f.readTime.value.trim();
    }

    try {
      // Preserve any existing reviews when editing rather than wiping them out.
      if (f.docId.value) {
        try {
          const existing = await apiGet(cfg.apiPath + "/" + f.docId.value);
          record.reviews = existing.reviews || [];
        } catch (e) {
          // no existing item with this id yet — fine, keep record.reviews as []
        }
      }
      await apiWrite(cfg.apiPath + "/" + docId, "PUT", record);
      setStatus(statusEl, "Saved.", false);
      closeForm(kind);
      loadList(kind);
    } catch (err) {
      setStatus(statusEl, "Could not save: " + err.message, true);
    }
  });
}

wireKind("package");
wireKind("magazine");
