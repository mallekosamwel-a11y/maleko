/* ===================================================================
   Know Afrika — data.js
   Fallback content, used only if this server's own API can't be
   reached (server down, database not seeded yet, etc). The live
   source of truth is the SQLite database (see ../../db.js), served
   through /api/packages, /api/magazines, /api/settings — see
   data-loader.js. Keep this in the same shape as those API responses
   so the fallback is a seamless swap-in, not a degraded experience.
=================================================================== */

const FALLBACK_DATA = {

  brand: {
    name: "Know Afrika",
    tagline: "Happiness lives on the other side of the horizon."
  },

  footer: {
    legalName: "Know Afrika Tours & Travel",
    email: "hello@knowafrika.co.tz",
    phone: "+255 754 000 111",
    whatsapp: "255754000111",
    address: "Boma Road, Moshi, Kilimanjaro Region, Tanzania",
    mapsQuery: "Boma Road, Moshi, Tanzania",
    socials: [
      { name: "Instagram", url: "https://instagram.com/knowafrika", icon: "instagram" },
      { name: "Facebook",  url: "https://facebook.com/knowafrika",  icon: "facebook" },
      { name: "X",         url: "https://x.com/knowafrika",         icon: "x" },
      { name: "YouTube",   url: "https://youtube.com/@knowafrika",  icon: "youtube" }
    ]
  },

  packages: [
    {
      id: "kilimanjaro-machame", type: "package", featured: true,
      title: "Kilimanjaro — Machame Route",
      location: "Kilimanjaro National Park, Tanzania",
      image: "https://images.unsplash.com/photo-1621414050345-53db43f7e7ab?auto=format&fit=crop&w=1200&h=800&q=80",
      date: "Departs every Monday & Thursday",
      duration: "7 days / 6 nights",
      price: 1850, currency: "USD", priceUnit: "per person",
      rating: 4.8, ratingCount: 132,
      summary: "The 'Whiskey Route' — forest, moorland, alpine desert and the roof of Africa, over seven acclimatisation-friendly days.",
      body: [
        { type: "text", content: "The Machame Route climbs through four distinct climate zones before the final push to Uhuru Peak. Camps are set beside streams and beneath the southern glaciers, giving climbers a longer window to acclimatise than the shorter routes." },
        { type: "image", src: "https://images.unsplash.com/photo-1621414050946-1b936a78491f?auto=format&fit=crop&w=1000&h=650&q=80", caption: "Climbers move slowly ('polepole') up Kilimanjaro's slopes to help the body acclimatize." },
        { type: "text", content: "Day four's Barranco Wall is the technical highlight — a scramble rather than a climb, and over within an hour — after which the route contours beneath the Southern Icefields toward base camp." },
        { type: "text", content: "Summit night departs from Barafu Camp around midnight, reaching Stella Point by sunrise and Uhuru Peak — 5,895m — shortly after. Descent continues the same day to Mweka Camp." }
      ],
      operator: {
        name: "Maleko Treks & Safaris",
        address: "Kimangara, Moshi Rural, Kilimanjaro Region",
        location: "Moshi, Tanzania",
        email: "maleko@knowafrika.co.tz",
        phone: "+255 767 112 233",
        socials: [
          { name: "WhatsApp", url: "https://wa.me/255767112233", icon: "whatsapp" },
          { name: "Instagram", url: "https://instagram.com/malekotreks", icon: "instagram" }
        ]
      },
      reviews: [
        { id: "r1", author: "Amara O.", rating: 5, date: "2026-06-02", comment: "Our guide read the mountain and the group perfectly — never rushed, never behind schedule. Stella Point at sunrise was worth every step.", likes: 9 },
        { id: "r2", author: "Devon K.", rating: 4, date: "2026-05-14", comment: "Excellent crew and food. Barranco Wall was less scary than I'd built it up to be in my head!", likes: 4 }
      ]
    },
    {
      id: "serengeti-migration-safari", type: "package", featured: true,
      title: "Serengeti Migration Safari",
      location: "Serengeti National Park, Tanzania",
      image: "https://images.unsplash.com/photo-1564101160531-4838e8a5f4e7?auto=format&fit=crop&w=1200&h=800&q=80",
      date: "Best Jun–Sep, runs year-round",
      duration: "5 days / 4 nights",
      price: 2100, currency: "USD", priceUnit: "per person",
      rating: 4.9, ratingCount: 201,
      summary: "Follow the wildebeest migration across open plains, with river-crossing viewpoints and a night at a mobile tented camp.",
      body: [
        { type: "text", content: "Game drives are timed around the migration's seasonal position, tracked daily by our guides, rather than fixed to a single camp. Early starts favour predator activity; the middle of the day is kept for camp, lunch and rest." },
        { type: "image", src: "https://images.unsplash.com/photo-1564101160531-4838e8a5f4e7?auto=format&fit=crop&w=1000&h=650&q=80", caption: "The wildebeest migration crossing the Mara River in Serengeti National Park." },
        { type: "text", content: "Nights are split between a permanent lodge on the plains and a smaller mobile camp closer to the herds, giving both comfort and proximity depending on where the migration sits that week." }
      ],
      operator: {
        name: "Savanna Trail Safaris",
        address: "Fedha Estate, Arusha",
        location: "Arusha, Tanzania",
        email: "bookings@savannatrail.co.tz",
        phone: "+255 754 998 221",
        socials: [
          { name: "WhatsApp", url: "https://wa.me/255754998221", icon: "whatsapp" },
          { name: "Facebook", url: "https://facebook.com/savannatrail", icon: "facebook" }
        ]
      },
      reviews: [
        { id: "r3", author: "Priya S.", rating: 5, date: "2026-07-20", comment: "Saw two crossings in three days. The mobile camp night was the highlight — you can hear the plains at night.", likes: 11 }
      ]
    },
    {
      id: "zanzibar-stone-town-beach", type: "package", featured: false,
      title: "Zanzibar: Stone Town & Beach",
      location: "Zanzibar Archipelago, Tanzania",
      image: "https://images.unsplash.com/photo-1502452302126-a987e1f3fea4?auto=format&fit=crop&w=1200&h=800&q=80",
      date: "Available year-round",
      duration: "4 days / 3 nights",
      price: 690, currency: "USD", priceUnit: "per person",
      rating: 4.6, ratingCount: 87,
      summary: "Spice-market mornings in Stone Town, an afternoon dhow sail, and two full days on Zanzibar's northeast coast.",
      body: [
        { type: "text", content: "Stone Town's alleys are covered on foot with a local historian guide, taking in the old fort, the spice market and the House of Wonders exterior, before transferring north to the coast." },
        { type: "image", src: "https://images.unsplash.com/photo-1511684633137-6b5fc88b3dbc?auto=format&fit=crop&w=1000&h=650&q=80", caption: "Sunset over the water at Nungwi, on Zanzibar's northern coast." }
      ],
      operator: {
        name: "Unguja Coastal Tours",
        address: "Kenyatta Road, Stone Town",
        location: "Zanzibar City, Tanzania",
        email: "info@ungujacoastal.co.tz",
        phone: "+255 777 456 890",
        socials: [
          { name: "Instagram", url: "https://instagram.com/ungujacoastal", icon: "instagram" }
        ]
      },
      reviews: []
    }
  ],

  magazines: [
    {
      id: "reading-kilimanjaro-seasons", type: "magazine", featured: true,
      title: "Reading Kilimanjaro's Seasons Like a Guide",
      location: "Kilimanjaro Region",
      image: "https://images.unsplash.com/photo-1621414050946-1b936a78491f?auto=format&fit=crop&w=1200&h=800&q=80",
      date: "Published 12 July 2026",
      author: "Neema Massawe",
      readTime: "6 min read",
      rating: 4.7, ratingCount: 41,
      summary: "What local guides actually watch for before recommending a climbing month — and why the tourist calendar and the mountain's calendar don't quite agree.",
      body: [
        { type: "text", content: "Most booking sites describe two dry windows — January to March and June to October — but guides who work the mountain year-round talk about the transitions between those windows just as much as the windows themselves." },
        { type: "image", src: "https://images.unsplash.com/photo-1621414050345-53db43f7e7ab?auto=format&fit=crop&w=1000&h=650&q=80", caption: "Climbers reach Uhuru Peak, Kilimanjaro's summit, above the clouds." },
        { type: "text", content: "The short rains in November thin out crowds on the Machame and Lemosho routes considerably, and guides who know the cloud patterns can often call a clear summit morning even in a 'wet' month." }
      ],
      operator: {
        name: "Know Afrika Editorial",
        address: "Boma Road, Moshi",
        location: "Moshi, Tanzania",
        email: "editorial@knowafrika.co.tz",
        phone: "+255 754 000 111",
        socials: [ { name: "X", url: "https://x.com/knowafrika", icon: "x" } ]
      },
      reviews: [
        { id: "m1", author: "Grace T.", rating: 5, date: "2026-07-15", comment: "This matched what our guide told us almost word for word. Wish I'd read it before booking.", likes: 6 }
      ]
    },
    {
      id: "beyond-safari-southern-circuit", type: "magazine", featured: true,
      title: "Beyond the Northern Safari Circuit",
      location: "Southern Tanzania",
      image: "https://images.unsplash.com/photo-1664270749275-19d5ee4f9bdc?auto=format&fit=crop&w=1200&h=800&q=80",
      date: "Published 2 July 2026",
      author: "Elias Mwakalinga",
      readTime: "8 min read",
      rating: 4.5, ratingCount: 29,
      summary: "Ruaha and Nyerere see a fraction of the Serengeti's visitors — a look at what that changes about the experience.",
      body: [
        { type: "text", content: "The southern parks require more flying and fewer roads, which keeps vehicle density low even in peak season. That trade-off is the entire pitch: fewer other travellers, more unscripted wildlife behaviour." },
        { type: "text", content: "Elephant herds are a near-daily sighting along the river systems that thread through Ruaha and Nyerere, often at closer range than the more heavily-visited northern parks allow." }
      ],
      operator: {
        name: "Know Afrika Editorial",
        address: "Boma Road, Moshi",
        location: "Moshi, Tanzania",
        email: "editorial@knowafrika.co.tz",
        phone: "+255 754 000 111",
        socials: [ { name: "Facebook", url: "https://facebook.com/knowafrika", icon: "facebook" } ]
      },
      reviews: []
    },
    {
      id: "packing-list-summit-night", type: "magazine", featured: false,
      title: "The Packing List That Survives Summit Night",
      location: "Kilimanjaro Region",
      image: "https://images.unsplash.com/photo-1636447670364-9dc6c2a0f489?auto=format&fit=crop&w=1200&h=800&q=80",
      date: "Published 25 June 2026",
      author: "Neema Massawe",
      readTime: "5 min read",
      rating: 4.9, ratingCount: 63,
      summary: "Base camp is warm at noon and brutal at midnight. A layer-by-layer look at what actually holds up on the summit push.",
      body: [
        { type: "text", content: "Temperatures at Barafu Camp can swing more than 30°C between midday and the 11pm summit departure, which catches more climbers out than altitude does." },
        { type: "image", src: "https://images.unsplash.com/photo-1621414050946-1b936a78491f?auto=format&fit=crop&w=1000&h=650&q=80", caption: "Every layer earns its place in the pack for the push up Kilimanjaro." }
      ],
      operator: {
        name: "Know Afrika Editorial",
        address: "Boma Road, Moshi",
        location: "Moshi, Tanzania",
        email: "editorial@knowafrika.co.tz",
        phone: "+255 754 000 111",
        socials: []
      },
      reviews: []
    }
  ]

};
