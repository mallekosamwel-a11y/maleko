/* ===================================================================
   Know Afrika — app.js
   Reads SITE_DATA (see data.js) and renders every part of the page.
   Nothing here should need editing to add/change content — that all
   happens in data.js. This file is logic only.
=================================================================== */
(function () {
  "use strict";

  let SITE_DATA = null;

  const ICONS = {
    instagram: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r="1"/></svg>',
    facebook: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M14 9h3V6h-3c-2.2 0-4 1.8-4 4v2H8v3h2v6h3v-6h2.6l.4-3H13v-1.6c0-.8.4-1.4 1-1.4Z"/></svg>',
    x: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M4 4l7.2 9.1L4.4 20h2.3l5.9-6.4L17.4 20H20l-7.6-9.6L19.6 4h-2.3l-5.4 5.9L7 4H4Z"/></svg>',
    youtube: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M21.5 7.6c-.2-1-1-1.8-2-2C17.7 5.2 12 5.2 12 5.2s-5.7 0-7.5.4c-1 .2-1.8 1-2 2C2.2 9.4 2.2 12 2.2 12s0 2.6.3 4.4c.2 1 1 1.8 2 2 1.8.4 7.5.4 7.5.4s5.7 0 7.5-.4c1-.2 1.8-1 2-2 .3-1.8.3-4.4.3-4.4s0-2.6-.3-4.4ZM10 15V9l5.2 3-5.2 3Z"/></svg>',
    whatsapp: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 3a9 9 0 0 0-7.7 13.6L3 21l4.6-1.2A9 9 0 1 0 12 3Zm0 16.3a7.3 7.3 0 0 1-3.7-1l-.3-.2-2.6.7.7-2.5-.2-.3A7.3 7.3 0 1 1 12 19.3Zm4-5.4c-.2-.1-1.3-.6-1.5-.7-.2-.1-.3-.1-.5.1l-.6.8c-.1.2-.3.2-.5.1-1.3-.5-2.2-1.4-2.7-2.7-.1-.2 0-.4.1-.5l.5-.6c.1-.2.1-.4 0-.5l-.5-1.2c-.1-.3-.3-.3-.5-.3h-.5c-.2 0-.5.1-.6.3-.2.3-.7.9-.7 2.1s.9 2.5 1 2.6c.1.2 1.7 2.6 4.1 3.5 2 .8 2 .5 2.4.5.4-.1 1.3-.5 1.5-1 .2-.5.2-.9.1-1Z"/></svg>',
    email: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M4 6.5 12 13l8-6.5"/></svg>',
    phone: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6.6 10.8c1.4 2.8 3.8 5.2 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.2.5 2.5.8 3.9.8.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C11.6 21 3 12.4 3 2.7c0-.6.4-1 1-1h3.3c.6 0 1 .4 1 1 0 1.4.3 2.7.8 3.9.1.3.1.7-.2 1L6.6 10.8Z"/></svg>',
    pin: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s7-6.1 7-11.3A7 7 0 0 0 5 9.7C5 14.9 12 21 12 21Z"/><circle cx="12" cy="9.5" r="2.3"/></svg>'
  };
  const icon = (name) => ICONS[name] || "";

  const allItems = () => SITE_DATA.packages.concat(SITE_DATA.magazines);
  const findItem = (type, id) => (type === "package" ? SITE_DATA.packages : SITE_DATA.magazines).find(i => i.id === id);
  const money = (item) => item.currency + " " + item.price.toLocaleString() + " " + item.priceUnit;
  const stars = (rating) => {
    const full = Math.round(rating);
    return "★★★★★".slice(0, full) + "☆☆☆☆☆".slice(0, 5 - full);
  };
  const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const avgRating = (item) => {
    if (!item.reviews.length) return item.rating;
    const sum = item.reviews.reduce((a, r) => a + r.rating, 0) + (item.rating * item.ratingCount);
    return sum / (item.reviews.length + item.ratingCount);
  };

  /* ---------------------------- cards ---------------------------- */
  function renderCard(item) {
    const metaRight = item.type === "package"
      ? '<span class="card-price">' + esc(item.currency) + " " + item.price.toLocaleString() + "</span>"
      : '<span class="card-price">' + esc(item.readTime) + "</span>";
    return (
      "<li>" +
        '<a class="card" href="#item/' + item.type + "/" + item.id + '">' +
          '<div class="card-media">' +
            '<img src="' + item.image + '" alt="" loading="lazy">' +
          "</div>" +
          '<h3>' + esc(item.title) + "</h3>" +
          '<p class="card-meta">' +
            '<span class="stars" aria-hidden="true">' + stars(avgRating(item)) + "</span>" +
            '<span class="visually-hidden">Rated ' + avgRating(item).toFixed(1) + " out of 5</span>" +
            metaRight +
          "</p>" +
        "</a>" +
      "</li>"
    );
  }

  function renderCardGrid(items, emptyLabel) {
    if (!items.length) return '<div class="empty-state">' + esc(emptyLabel || "Nothing here yet.") + "</div>";
    return '<ul class="card-grid">' + items.map(renderCard).join("") + "</ul>";
  }

  /* ---------------------------- views ---------------------------- */
  function viewHome() {
    const featured = allItems().filter(i => i.featured);
    return (
      '<section aria-labelledby="highlights-heading">' +
        '<div class="section-heading">' +
          '<span class="eyebrow">Handpicked this week</span>' +
          '<h2 id="highlights-heading">Highlighted packages &amp; magazines</h2>' +
        "</div>" +
        renderCardGrid(featured, "No highlighted listings yet.") +
      "</section>"
    );
  }

  function viewList(type) {
    const items = type === "package" ? SITE_DATA.packages : SITE_DATA.magazines;
    const label = type === "package" ? "Packages" : "Magazines";
    return (
      '<section aria-labelledby="list-heading">' +
        '<div class="section-heading">' +
          '<span class="eyebrow">' + items.length + " listed</span>" +
          '<h2 id="list-heading">' + label + "</h2>" +
        "</div>" +
        renderCardGrid(items, "No " + label.toLowerCase() + " available right now.") +
      "</section>"
    );
  }

  function viewSearch(query) {
    const q = query.trim().toLowerCase();
    const results = allItems().filter(i =>
      i.title.toLowerCase().includes(q) ||
      (i.location || "").toLowerCase().includes(q) ||
      (i.summary || "").toLowerCase().includes(q)
    );
    return (
      '<section aria-labelledby="search-heading">' +
        '<div class="section-heading">' +
          '<span class="eyebrow">' + results.length + " result" + (results.length === 1 ? "" : "s") + "</span>" +
          '<h2 id="search-heading">Search: &quot;' + esc(query) + '&quot;</h2>' +
        "</div>" +
        renderCardGrid(results, "No packages or magazines matched that search.") +
      "</section>"
    );
  }

  function renderBodyBlocks(blocks) {
    return blocks.map(b => {
      if (b.type === "image") {
        return '<figure><img src="' + b.src + '" alt="' + esc(b.caption || "") + '" loading="lazy">' +
               (b.caption ? "<figcaption>" + esc(b.caption) + "</figcaption>" : "") + "</figure>";
      }
      return "<p>" + esc(b.content) + "</p>";
    }).join("");
  }

  function renderOperatorBlock(op) {
    const socials = (op.socials || []).map(s =>
      '<a href="' + s.url + '" target="_blank" rel="noopener" aria-label="' + esc(op.name) + " on " + esc(s.name) + '">' + icon(s.icon) + "</a>"
    ).join(" ");
    return (
      '<section class="operator-block" aria-label="Operator details">' +
        "<h3>Offered by " + esc(op.name) + "</h3>" +
        '<div class="operator-grid">' +
          '<div><span class="label">Address</span><div class="value">' + esc(op.address) + "</div></div>" +
          '<div><span class="label">Location</span><div class="value">' + esc(op.location) + "</div></div>" +
          '<div><span class="label">Email</span><div class="value"><a href="mailto:' + op.email + '">' + esc(op.email) + "</a></div></div>" +
          '<div><span class="label">Phone</span><div class="value"><a href="tel:' + op.phone.replace(/\s+/g, "") + '">' + esc(op.phone) + "</a></div></div>" +
        "</div>" +
        (socials ? '<p>' + socials + "</p>" : "") +
      "</section>"
    );
  }

  function renderReviews(item) {
    const rating = avgRating(item);
    const list = item.reviews.length
      ? '<ul class="review-list">' + item.reviews.map(r =>
          '<li class="review" data-review-id="' + r.id + '">' +
            '<p><strong>' + esc(r.author) + "</strong> — <small>" + esc(r.date) + "</small></p>" +
            '<div class="review-stars" aria-hidden="true">' + stars(r.rating) + "</div>" +
            "<p>" + esc(r.comment) + "</p>" +
            '<button type="button" class="like-btn" data-like-id="' + r.id + '" aria-pressed="false">' +
              "♥ <span class=\"like-count\">" + r.likes + "</span>" +
              '<span class="visually-hidden"> — like this review</span>' +
            "</button>" +
          "</li>"
        ).join("") + "</ul>"
      : '<div class="empty-state">No reviews yet — be the first to share your experience.</div>';

    return (
      '<section class="reviews-section" aria-labelledby="reviews-heading">' +
        "<p><strong>" + rating.toFixed(1) + "</strong> <span class=\"stars\" aria-hidden=\"true\">" + stars(rating) + "</span> — " +
          (item.ratingCount + item.reviews.length) + " review" + ((item.ratingCount + item.reviews.length) === 1 ? "" : "s") +
        "</p>" +
        '<h3 id="reviews-heading">What viewers say</h3>' +
        list +
        '<form class="review-form" id="review-form" aria-label="Add your review">' +
          "<h3>Add your rating and comment</h3>" +
          '<div class="star-picker" role="radiogroup" aria-label="Your rating">' +
            [1, 2, 3, 4, 5].map(n => '<button type="button" role="radio" aria-checked="false" data-star="' + n + '" aria-label="' + n + " star" + (n > 1 ? "s" : "") + '">★</button>').join("") +
          "</div>" +
          '<label for="review-name">Your name</label>' +
          '<input type="text" id="review-name" required placeholder="How should we show your name?">' +
          '<label for="review-comment">Your comment</label>' +
          '<textarea id="review-comment" rows="3" required placeholder="Tell other travellers what stood out."></textarea>' +
          '<button type="submit" class="btn">Post review</button>' +
          '<p><small>Your rating and comment appear immediately below for this session.</small></p>' +
        "</form>" +
      "</section>"
    );
  }

  function viewDetail(type, id) {
    const item = findItem(type, id);
    if (!item) return '<div class="empty-state">That listing could not be found. <a href="#">Return home</a>.</div>';

    const metaItems = [];
    metaItems.push('<div class="meta-item"><span class="label">' + (type === "package" ? "Departure" : "Published") + '</span><span class="value">' + esc(item.date) + "</span></div>");
    if (type === "package") {
      metaItems.push('<div class="meta-item"><span class="label">Duration</span><span class="value">' + esc(item.duration) + "</span></div>");
    } else {
      metaItems.push('<div class="meta-item"><span class="label">By</span><span class="value">' + esc(item.author) + "</span></div>");
    }
    metaItems.push('<div class="meta-item"><span class="label">Rating</span><span class="value">' + avgRating(item).toFixed(1) + " / 5</span></div>");
    if (type === "package") {
      metaItems.push('<div class="meta-item"><span class="label">Price</span><span class="value price">' + money(item) + "</span></div>");
    } else {
      metaItems.push('<div class="meta-item"><span class="label">Read time</span><span class="value">' + esc(item.readTime) + "</span></div>");
    }

    return (
      '<article aria-labelledby="detail-heading">' +
        '<p><a href="#' + (type === "package" ? "packages" : "magazines") + '">&larr; Back to ' + (type === "package" ? "packages" : "magazines") + "</a></p>" +
        '<div class="detail-hero"><img src="' + item.image + '" alt=""></div>' +
        '<span class="eyebrow">' + esc(item.location) + "</span>" +
        '<h1 id="detail-heading">' + esc(item.title) + "</h1>" +
        '<div class="detail-meta">' + metaItems.join("") + "</div>" +
        '<div class="detail-body">' +
          '<p class="lead">' + esc(item.summary) + "</p>" +
          renderBodyBlocks(item.body) +
        "</div>" +
        renderReviews(item) +
        renderOperatorBlock(item.operator) +
      "</article>"
    );
  }

  /* --------------------------- routing --------------------------- */
  const routes = {
    "": viewHome,
    packages: () => viewList("package"),
    magazines: () => viewList("magazine")
  };

  const currentRoute = () => decodeURIComponent(location.hash.replace(/^#\/?/, ""));

  function render() {
    const app = document.getElementById("app");
    const route = currentRoute();
    const parts = route.split("/");
    let html, announce;

    if (route.startsWith("item/") && parts.length >= 3) {
      html = viewDetail(parts[1], parts.slice(2).join("/"));
      announce = "Showing listing detail";
    } else if (route.startsWith("search/")) {
      const q = parts.slice(1).join("/");
      html = viewSearch(q);
      announce = "Showing search results for " + q;
    } else if (routes[route]) {
      html = routes[route]();
      announce = route === "" ? "Showing home" : "Showing " + route;
    } else {
      html = viewHome();
      announce = "Showing home";
    }

    app.innerHTML = html;
    document.getElementById("route-announcer").textContent = announce;
    updateNavState(route);
    bindDetailInteractions();
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  }

  function updateNavState(route) {
    document.querySelectorAll("#main-nav a").forEach(a => {
      const target = a.getAttribute("data-route");
      const match = target === route ||
        (target === "packages" && route.startsWith("item/package")) ||
        (target === "magazines" && route.startsWith("item/magazine"));
      if (match) a.setAttribute("aria-current", "page");
      else a.removeAttribute("aria-current");
    });
  }

  /* --------------------- reviews / likes (session only) --------------------- */
  function bindDetailInteractions() {
    const app = document.getElementById("app");

    app.querySelectorAll(".like-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const pressed = btn.getAttribute("aria-pressed") === "true";
        const countEl = btn.querySelector(".like-count");
        countEl.textContent = parseInt(countEl.textContent, 10) + (pressed ? -1 : 1);
        btn.setAttribute("aria-pressed", String(!pressed));
      });
    });

    const form = app.querySelector("#review-form");
    if (!form) return;

    let selectedStars = 0;
    const starButtons = form.querySelectorAll(".star-picker button");
    starButtons.forEach(b => {
      b.addEventListener("click", () => {
        selectedStars = parseInt(b.getAttribute("data-star"), 10);
        starButtons.forEach(sb => {
          const active = parseInt(sb.getAttribute("data-star"), 10) <= selectedStars;
          sb.setAttribute("aria-checked", String(active));
          sb.classList.toggle("filled", active);
        });
      });
    });

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const match = currentRoute().match(/^item\/([^/]+)\/(.+)$/);
      if (!match) return;
      const item = findItem(match[1], match[2]);
      if (!item) return;

      const name = form.querySelector("#review-name").value.trim() || "Guest traveller";
      const comment = form.querySelector("#review-comment").value.trim();
      if (!comment) return;

      item.reviews.unshift({
        id: "review-" + Date.now(),
        author: name,
        rating: selectedStars || 5,
        date: new Date().toISOString().slice(0, 10),
        comment: comment,
        likes: 0
      });
      render();
    });
  }

  /* --------------------------- chrome --------------------------- */
  function renderChrome() {
    document.getElementById("brand").textContent = SITE_DATA.brand.name;
    document.getElementById("tagline").textContent = SITE_DATA.brand.tagline;

    const navItems = [
      { label: "Packages", route: "packages" },
      { label: "Magazines", route: "magazines" }
    ];
    document.getElementById("nav-list").innerHTML = navItems.map(n =>
      '<li><a href="#' + n.route + '" data-route="' + n.route + '">' + esc(n.label) + "</a></li>"
    ).join("");

    const f = SITE_DATA.footer;
    const socialLinks = f.socials.map(s =>
      '<a href="' + s.url + '" target="_blank" rel="noopener" aria-label="' + esc(f.legalName) + " on " + esc(s.name) + '">' + icon(s.icon) + "</a>"
    ).join(" ");
    const mapsUrl = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(f.mapsQuery);

    document.getElementById("footer-inner").innerHTML =
      "<div><h3>" + esc(f.legalName) + "</h3><p>" + icon("pin") + " " + esc(f.address) + " — <a href=\"" + mapsUrl + "\">Open in Google Maps</a></p></div>" +
      "<div><h3>Contact</h3><p><a href=\"mailto:" + f.email + "\">" + icon("email") + " " + esc(f.email) + "</a></p>" +
      "<p><a href=\"tel:" + f.phone.replace(/\s+/g, "") + "\">" + icon("phone") + " " + esc(f.phone) + "</a></p>" +
      "<p><a href=\"https://wa.me/" + f.whatsapp + "\" target=\"_blank\" rel=\"noopener\">" + icon("whatsapp") + " WhatsApp us</a></p></div>" +
      "<div><h3>Follow</h3><p>" + socialLinks + "</p></div>";

    document.getElementById("footer-bottom").textContent =
      "© " + new Date().getFullYear() + " " + f.legalName + ". All rights reserved.";
  }

  /* ------------------------ header controls ------------------------ */
  function bindHeaderControls() {
    document.getElementById("search-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const q = document.getElementById("search-input").value.trim();
      if (q) location.hash = "#search/" + encodeURIComponent(q);
    });

    const navToggle = document.getElementById("nav-toggle");
    const navList = document.getElementById("nav-list");
    navToggle.addEventListener("click", () => {
      const open = navList.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(open));
    });
    navList.addEventListener("click", (e) => {
      if (e.target.tagName === "A") {
        navList.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });

    const themeToggle = document.getElementById("theme-toggle");
    const applyTheme = (theme) => {
      document.documentElement.setAttribute("data-theme", theme);
      themeToggle.setAttribute("aria-pressed", String(theme === "dark"));
      localStorage.setItem("know-afrika-theme", theme);
    };
    const saved = localStorage.getItem("know-afrika-theme");
    if (saved) applyTheme(saved);
    themeToggle.addEventListener("click", () => {
      const current = document.documentElement.getAttribute("data-theme") ||
        (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
      applyTheme(current === "dark" ? "light" : "dark");
    });
  }

  function initApp(data) {
    SITE_DATA = data;
    renderChrome();
    bindHeaderControls();
    window.addEventListener("hashchange", render);
    render();
  }

  window.KnowAfrika = { init: initApp };
})();
