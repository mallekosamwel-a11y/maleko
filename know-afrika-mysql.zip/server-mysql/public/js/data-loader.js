// ===================================================================
// Know Afrika — data-loader.js
// Fetches packages, magazines, and settings from this server's own
// API (same origin, so no need for a full URL). Falls back to
// FALLBACK_DATA (js/data.js) if the server can't be reached, so the
// site still works while the server is being set up.
// ===================================================================
(function () {
  "use strict";

  async function loadSiteData() {
    const [packages, magazines, settings] = await Promise.all([
      fetch("/api/packages").then(r => { if (!r.ok) throw new Error("packages request failed"); return r.json(); }),
      fetch("/api/magazines").then(r => { if (!r.ok) throw new Error("magazines request failed"); return r.json(); }),
      fetch("/api/settings").then(r => { if (!r.ok) throw new Error("settings request failed"); return r.json(); })
    ]);

    if (!packages.length && !magazines.length) {
      throw new Error("No packages or magazines found on the server yet");
    }

    return {
      brand: settings.brand,
      footer: settings.footer,
      packages: packages,
      magazines: magazines
    };
  }

  loadSiteData()
    .then(data => window.KnowAfrika.init(data))
    .catch(err => {
      console.warn("Know Afrika: falling back to local sample content —", err.message);
      window.KnowAfrika.init(FALLBACK_DATA);
    });
})();
