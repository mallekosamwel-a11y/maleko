// ===================================================================
// Know Afrika — create-admin.js
// Run this once to create your admin.html login.
//
//   node create-admin.js youremail@example.com yourpassword
//
// Running it again with the same email updates that account's
// password instead of creating a duplicate.
// ===================================================================

require("dotenv").config();
const bcrypt = require("bcryptjs");
const db = require("./db");

const [, , email, password] = process.argv;

if (!email || !password) {
  console.log("Usage: node create-admin.js youremail@example.com yourpassword");
  process.exit(1);
}

(async () => {
  try {
    const existing = await db.getAdminByEmail(email);
    const passwordHash = bcrypt.hashSync(password, 10);
    await db.upsertAdmin(email, passwordHash);
    console.log(existing ? "Updated password for:" : "Created admin login for:", email);
  } catch (err) {
    console.error("Could not create admin login:", err.message);
    console.error("Check your .env database settings (DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) are correct and the database is reachable.");
  } finally {
    process.exit();
  }
})();
