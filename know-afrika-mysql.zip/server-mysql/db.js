// ===================================================================
// Know Afrika — db.js
// MySQL, reached through a connection pool (a small set of reusable
// connections, handled automatically by mysql2 — you don't manage
// opening/closing connections yourself). Every function here is
// async, since MySQL queries always are — unlike the old SQLite
// version, which happened to be synchronous.
// ===================================================================

const mysql = require("mysql2/promise");
const fs = require("fs");
const path = require("path");

const pool = mysql.createPool({
  host: process.env.DB_HOST || "127.0.0.1",
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "know_afrika",
  waitForConnections: true,
  connectionLimit: 10,
  ssl: process.env.DB_SSL === "true" ? { rejectUnauthorized: true } : undefined
});

function packageRowToRecord(row) {
  if (!row) return null;
  return Object.assign({}, row, {
    type: "package",
    featured: !!row.featured,
    price: row.price !== null ? Number(row.price) : 0,
    rating: row.rating !== null ? Number(row.rating) : 0,
    body: JSON.parse(row.body || "[]"),
    operator: JSON.parse(row.operator || "{}"),
    reviews: JSON.parse(row.reviews || "[]")
  });
}

function magazineRowToRecord(row) {
  if (!row) return null;
  return Object.assign({}, row, {
    type: "magazine",
    featured: !!row.featured,
    rating: row.rating !== null ? Number(row.rating) : 0,
    body: JSON.parse(row.body || "[]"),
    operator: JSON.parse(row.operator || "{}"),
    reviews: JSON.parse(row.reviews || "[]")
  });
}

/* ------------------------------ packages ------------------------------ */

async function getPackages() {
  const [rows] = await pool.query("SELECT * FROM packages");
  return rows.map(packageRowToRecord);
}

async function getPackage(id) {
  const [rows] = await pool.query("SELECT * FROM packages WHERE id = ?", [id]);
  return packageRowToRecord(rows[0]);
}

async function savePackage(record) {
  await pool.query(
    `INSERT INTO packages (id, title, location, image, featured, date, duration, price, currency, priceUnit, rating, ratingCount, summary, body, operator, reviews)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       title=VALUES(title), location=VALUES(location), image=VALUES(image), featured=VALUES(featured),
       date=VALUES(date), duration=VALUES(duration), price=VALUES(price), currency=VALUES(currency),
       priceUnit=VALUES(priceUnit), rating=VALUES(rating), ratingCount=VALUES(ratingCount),
       summary=VALUES(summary), body=VALUES(body), operator=VALUES(operator), reviews=VALUES(reviews)`,
    [
      record.id, record.title, record.location || "", record.image || "", record.featured ? 1 : 0,
      record.date || "", record.duration || "", record.price || 0, record.currency || "USD",
      record.priceUnit || "", record.rating || 0, record.ratingCount || 0, record.summary || "",
      JSON.stringify(record.body || []), JSON.stringify(record.operator || {}), JSON.stringify(record.reviews || [])
    ]
  );
  return getPackage(record.id);
}

async function deletePackage(id) {
  await pool.query("DELETE FROM packages WHERE id = ?", [id]);
}

/* ------------------------------ magazines ------------------------------ */

async function getMagazines() {
  const [rows] = await pool.query("SELECT * FROM magazines");
  return rows.map(magazineRowToRecord);
}

async function getMagazine(id) {
  const [rows] = await pool.query("SELECT * FROM magazines WHERE id = ?", [id]);
  return magazineRowToRecord(rows[0]);
}

async function saveMagazine(record) {
  await pool.query(
    `INSERT INTO magazines (id, title, location, image, featured, date, author, readTime, rating, ratingCount, summary, body, operator, reviews)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       title=VALUES(title), location=VALUES(location), image=VALUES(image), featured=VALUES(featured),
       date=VALUES(date), author=VALUES(author), readTime=VALUES(readTime), rating=VALUES(rating),
       ratingCount=VALUES(ratingCount), summary=VALUES(summary), body=VALUES(body),
       operator=VALUES(operator), reviews=VALUES(reviews)`,
    [
      record.id, record.title, record.location || "", record.image || "", record.featured ? 1 : 0,
      record.date || "", record.author || "", record.readTime || "", record.rating || 0,
      record.ratingCount || 0, record.summary || "", JSON.stringify(record.body || []),
      JSON.stringify(record.operator || {}), JSON.stringify(record.reviews || [])
    ]
  );
  return getMagazine(record.id);
}

async function deleteMagazine(id) {
  await pool.query("DELETE FROM magazines WHERE id = ?", [id]);
}

/* ------------------------------ settings ------------------------------ */

async function getSettings() {
  const [rows] = await pool.query("SELECT * FROM site_config WHERE id = 1");
  const row = rows[0];
  if (!row) {
    return { brand: { name: "", tagline: "" }, footer: { legalName: "", email: "", phone: "", whatsapp: "", address: "", mapsQuery: "", socials: [] } };
  }
  return {
    brand: { name: row.brandName || "", tagline: row.tagline || "" },
    footer: {
      legalName: row.footerLegalName || "",
      email: row.footerEmail || "",
      phone: row.footerPhone || "",
      whatsapp: row.footerWhatsapp || "",
      address: row.footerAddress || "",
      mapsQuery: row.footerMapsQuery || "",
      socials: JSON.parse(row.footerSocials || "[]")
    }
  };
}

async function saveSettings({ brand, footer }) {
  await pool.query(
    `INSERT INTO site_config (id, brandName, tagline, footerLegalName, footerEmail, footerPhone, footerWhatsapp, footerAddress, footerMapsQuery, footerSocials)
     VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       brandName=VALUES(brandName), tagline=VALUES(tagline), footerLegalName=VALUES(footerLegalName),
       footerEmail=VALUES(footerEmail), footerPhone=VALUES(footerPhone), footerWhatsapp=VALUES(footerWhatsapp),
       footerAddress=VALUES(footerAddress), footerMapsQuery=VALUES(footerMapsQuery), footerSocials=VALUES(footerSocials)`,
    [
      brand?.name || "", brand?.tagline || "", footer?.legalName || "", footer?.email || "",
      footer?.phone || "", footer?.whatsapp || "", footer?.address || "", footer?.mapsQuery || "",
      JSON.stringify(footer?.socials || [])
    ]
  );
  return getSettings();
}

/* ------------------------------- admins ------------------------------- */

async function getAdminByEmail(email) {
  const [rows] = await pool.query("SELECT * FROM admins WHERE email = ?", [email]);
  return rows[0] || null;
}

async function upsertAdmin(email, passwordHash) {
  await pool.query(
    `INSERT INTO admins (email, passwordHash) VALUES (?, ?)
     ON DUPLICATE KEY UPDATE passwordHash = VALUES(passwordHash)`,
    [email, passwordHash]
  );
}

/* --------------------------- schema + seeding --------------------------- */

async function ensureSchema() {
  const schemaSql = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
  const statements = schemaSql.split(";").map(s => s.trim()).filter(Boolean);
  for (const stmt of statements) {
    await pool.query(stmt);
  }
}

async function seedIfEmpty() {
  const [rows] = await pool.query("SELECT COUNT(*) AS n FROM packages");
  if (rows[0].n > 0) return;

  const seedPath = path.join(__dirname, "seed-data.json");
  if (!fs.existsSync(seedPath)) return;

  const seed = JSON.parse(fs.readFileSync(seedPath, "utf8"));
  for (const p of seed.packages || []) await savePackage(p);
  for (const m of seed.magazines || []) await saveMagazine(m);
  await saveSettings({ brand: seed.brand, footer: seed.footer });
  console.log("Seeded database with sample content from seed-data.json");
}

module.exports = {
  getPackages, getPackage, savePackage, deletePackage,
  getMagazines, getMagazine, saveMagazine, deleteMagazine,
  getSettings, saveSettings,
  getAdminByEmail, upsertAdmin,
  ensureSchema, seedIfEmpty
};
