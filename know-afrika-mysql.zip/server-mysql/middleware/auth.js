// ===================================================================
// Know Afrika — middleware/auth.js
// Checks that requests to protected routes carry a valid login token.
// ===================================================================

const jwt = require("jsonwebtoken");

// In production, set JWT_SECRET in a .env file instead of using this
// default — see README.md.
const SECRET = process.env.JWT_SECRET || "know-afrika-dev-secret-change-me";

function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Sign in required." });
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch (err) {
    res.status(401).json({ error: "Your session has expired. Please sign in again." });
  }
}

module.exports = { requireAuth, SECRET };
